﻿using shopbridge_base.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace shopbridge_base.Repository
{
    public interface IInventoryRepository
    {
        Task<IEnumerable<InventoryModel>> get();
        Task<InventoryModel> get(long id);
        Task<InventoryModel> create(InventoryModel _Inventory);
        Task Update(InventoryModel _Inventory);
        Task Delete(long id);
    }
}
