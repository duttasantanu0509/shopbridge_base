﻿using shopbridge_base.Data;
using shopbridge_base.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace shopbridge_base.Repository
{
    public class InventoryRepository : IInventoryRepository
    {
        private readonly Shopbridge_Context _context;

        public InventoryRepository(Shopbridge_Context context)
        {
            _context = context;
        }
        public async Task<InventoryModel> create(InventoryModel _Inventory)
        {
            _context.Inventory.Add(_Inventory);
            await _context.SaveChangesAsync();

            return _Inventory;
        }


        public async Task Delete(long id)
        {
            var InventoryToDelete = await _context.Inventory.FindAsync(id);
            _context.Inventory.Remove(InventoryToDelete);
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<InventoryModel>> get()
        {
            return _context.Inventory.ToList();
        }

        public async Task<InventoryModel> get(long id)
        {
            return await _context.Inventory.FindAsync(id);
        }

        public async Task Update(InventoryModel _Inventory)
        {
            _context.Entry(_Inventory).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            await _context.SaveChangesAsync();
        }

    }
}
