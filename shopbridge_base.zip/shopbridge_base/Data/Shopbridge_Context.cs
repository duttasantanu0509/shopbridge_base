﻿using Microsoft.EntityFrameworkCore;
using shopbridge_base.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace shopbridge_base.Data
{
    public class Shopbridge_Context : DbContext
    {
        public Shopbridge_Context(DbContextOptions<Shopbridge_Context> options)
           : base(options)
        {
            Database.EnsureCreated();
        }

        public DbSet<InventoryModel> Inventory { get; set; }
    }
}
