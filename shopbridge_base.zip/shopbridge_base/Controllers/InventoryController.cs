﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using shopbridge_base.Models;
using shopbridge_base.Repository;

namespace shopbridge_base.Controllers
{
    public class InventoryController : Controller
    {
        public readonly IInventoryRepository _InventoryRepositoriesInventory;

        public InventoryController(IInventoryRepository _Inventory)
        {
            _InventoryRepositoriesInventory = _Inventory;
        }
        //Lists the items in the inventory.
        [HttpGet]
        public async Task<IEnumerable<InventoryModel>> GetInventories()
        {
            return await _InventoryRepositoriesInventory.get();
        }
        [HttpGet("{long}")]
        public async Task<ActionResult<InventoryModel>> GetInventory(long id)
        {
            return await _InventoryRepositoriesInventory.get(id);

        }
        //Add a new item to the inventory
        [HttpPost]
        public async Task<ActionResult<InventoryModel>> SaveInventory(InventoryModel _InventoryData)
        {
            var newinventory = await _InventoryRepositoriesInventory.create(_InventoryData);
            return CreatedAtAction(nameof(GetInventory), new { id = newinventory.id }, newinventory);

        }
        // Modify an item in the inventory
        [HttpPut]
        public async Task<ActionResult<InventoryModel>> UpdateInventory(long id, InventoryModel _InventoryData)
        {
            if (id != _InventoryData.id)
            {
                return BadRequest();
            }
            await _InventoryRepositoriesInventory.Update(_InventoryData);
            return NoContent();
        }
        [HttpDelete("{long}")]
        public async Task<ActionResult> DeleteInventory(long id)
        {
            var InventoryData = await _InventoryRepositoriesInventory.get(id);
            if (InventoryData == null)
            {
                return NoContent();
            }
            await _InventoryRepositoriesInventory.Delete(id);
            return NoContent();
        }
    }
}
